from django.apps import AppConfig


class MstfConfig(AppConfig):
    name = 'mstf'
