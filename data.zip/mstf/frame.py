#my framework
def msg_maker(*a):
	print "[*] "+a[0]+"  ".join(list(a)[1:])