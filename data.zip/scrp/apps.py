from django.apps import AppConfig


class ScrpConfig(AppConfig):
    name = 'scrp'
