from django.apps import AppConfig


class SecuritypConfig(AppConfig):
    name = 'securityp'
